<details><summary>1. 目标描述</summary>
本项目旨在设计并实现一个基于eBPF（Extended Berkeley Packet Filter）技术的增强型网络文件系统（NFS）。eBPF是一种强大的工具，能够在不修改内核代码的情况下扩展Linux内核功能，并且可以方便地加载和卸载扩展功能而无需重启系统。通过将eBPF与NFS结合，我们可以在内核态处理部分文件请求，从而减少用户态处理的开销，提高整体系统效率。

具体目标包括：

1. **内核态处理文件请求**：设计并实现一个系统，能够在内核态处理NFS客户端发送的部分文件请求。仅在无法在内核态处理的情况下，才将请求发送到用户态处理。这种方法可以显著减少上下文切换，提高NFS响应速度和整体效率。

2. **基本功能实现**：实现一个基本的网络文件系统功能，确保系统能够处理常见的文件操作请求，如读取、写入、创建和删除等。

3. **安全性增强**：利用eBPF的检测和监控能力，对NFS的行为进行实时统计和分析。通过定义和划分网络文件系统的安全行为，监测并识别潜在的安全威胁，增强NFS的安全性。

4. **行为监测和分析**：设计并实现一个基于eBPF的监测系统，对网络文件系统的行为进行详细的统计和分析，提供实时的安全监测和性能评估。

本项目不仅在技术上探索eBPF与NFS结合的可能性，还旨在提升网络文件系统的性能和安全性，为实际应用提供一个高效、安全的解决方案。通过此项目的实施，期望能够在网络文件系统的性能优化和安全性保障方面取得突破，为相关领域的研究和开发提供参考。
</details>
<details><summary>2. 比赛题目分析和相关资料调研</summary>

### 比赛题目分析

本项目的核心在于结合eBPF和NFS技术，设计并实现一个高效且安全的网络文件系统。通过在内核态处理部分文件请求和利用eBPF的监测能力，提升NFS的整体性能和安全性。这一题目主要涉及以下几个方面的挑战和目标：

1. **内核态处理请求**：
   - **挑战**：如何利用eBPF实现内核态文件请求处理，并确保其正确性和效率。
   - **目标**：在内核态处理尽可能多的文件请求，减少用户态处理的开销，提高系统的整体响应速度。

2. **基本功能实现**：
   - **挑战**：确保NFS的基本功能（如读写操作）的实现，同时兼顾系统的稳定性和性能。
   - **目标**：实现一个基本的NFS系统，能够正确处理常见的文件操作请求。

3. **安全性增强**：
   - **挑战**：如何利用eBPF监测NFS的行为，并定义和识别潜在的安全威胁。
   - **目标**：通过实时监测和分析NFS的行为，提高系统的安全性，防范潜在的安全威胁。

4. **行为监测和分析**：
   - **挑战**：如何设计一个高效的监测系统，能够实时统计和分析NFS的行为。
   - **目标**：提供一个详细的行为监测系统，实时评估NFS的性能和安全性。

### 相关资料调研

1. **eBPF概述及其应用**
   - eBPF是一种用于扩展Linux内核功能的技术，可以在内核态执行用户定义的代码，无需修改内核代码  。它在网络包过滤、性能监控和安全性增强等方面有广泛应用。

2. **NFS概述及其基本功能**
   - NFS是一种允许不同计算机系统之间共享文件的网络文件系统。它通过服务器-客户端模式工作，服务器端处理客户端发送的文件操作请求 。

3. **eBPF与NFS的结合**
   - 将eBPF与NFS结合，可以在内核态处理文件请求，减少用户态处理的开销。具体方法包括利用eBPF程序挂载在特定的钩子点上，如网络包过滤点和系统调用点，以拦截并处理相关请求  。

4. **相关技术和工具**
   - **bcc (BPF Compiler Collection)**：用于编写、编译和加载eBPF程序的工具集 。
   - **bpftool**：用于管理和调试eBPF程序的工具 。
   - **BPF Type Format (BTF)**：一种用于描述eBPF程序数据结构的格式，方便调试和开发 。

5. **eBPF应用案例**
   - 在网络性能监控方面，eBPF可以用于实时监控网络流量，检测异常行为 。
   - 在安全性增强方面，eBPF可以用于定义和监测特定的系统行为，防范潜在的安全威胁 。

6. **NFS性能优化**
   - 通过在内核态处理文件请求，可以减少用户态和内核态之间的上下文切换，从而提高NFS的整体性能 。
   - 利用eBPF进行实时监测和分析，可以及时发现和处理性能瓶颈，进一步优化NFS的性能 。

### 参考资料
1. coolshell.cn: [eBPF介绍](https://coolshell.cn/articles/22320.html)
2. developer.aliyun.com: [深入eBPF原理及应用](https://developer.aliyun.com/article/1275264)
3. csdn.net: [NFS介绍与使用](https://blog.csdn.net/mushuangpanny/article/details/127097977)
4. RFC7530:[NFS文档](https://www.rfc-editor.org/rfc/rfc7530#page-12)

通过这些分析和调研，我们可以清晰地了解eBPF与NFS结合的潜力和挑战，为后续的系统设计和实现提供坚实的理论基础和技术支持。
</details>
<details><summary>3. 系统框架设计</summary>
基于eBPF实现的增强型网络文件系统的设计目标是提高NFS的效率和安全性。系统框架设计主要包括以下几个部分：eBPF程序、用户态程序、内核态处理、以及NFS请求处理。下面是详细的系统框架设计。

### 1. 系统架构概述

整个系统由以下几部分组成：
- **eBPF程序**：用于拦截和处理NFS请求，直接在内核态处理部分请求，减少用户态处理的开销。
- **用户态程序**：用于加载、管理和监控eBPF程序，并与内核态程序进行交互。
- **NFS服务器**：提供网络文件系统服务，处理客户端的文件操作请求。

### 2. OPenEuler中的客户端和服务器的环境配置
#### 2.1 OpenEuler22.03中eBPF环境配置
##### 移除现有的BPFCC工具和库

```
dnf remove -y bpfcc-tools libbpfcc python3-bpfcc
```



##### 下载并解压BCC源码包

```
wget https://github.com/iovisor/bcc/releases/download/v0.25.0/bcc-src-with-submodule.tar.gz
tar xf bcc-src-with-submodule.tar.gz
cd bcc/
mkdir build
cd build/
```



##### 安装所需的依赖包

ln -s /usr/bin/python3 /usr/bin/python
dnf install -y bison make cmake flex git libedit-devel zlib-devel elfutils-libelf-devel flex-devel python3-distutils-extra llvm llvm-devel clang clang-devel

##### 安装fpm

由于`checkinstall`在新版本的glibc上存在兼容性问题，因此可以使用`fpm`（Effing Package Management）来生成软件包：

1. 安装`fpm`：

首先，安装`ruby`和`rubygems`：

```bash
dnf install -y ruby ruby-devel rubygems gcc make
```

然后，使用`gem`安装`fpm`：

```bash
gem install --no-document fpm
```

2. 使用`fpm`生成软件包并安装BCC：

在编译完成后，使用`fpm`生成RPM包：

```bash
# 编译BCC
cd /path/to/bcc/build
cmake -DCMAKE_INSTALL_PREFIX=/usr -DPYTHON_CMD=python3 ..
make

# 安装到临时目录并创建RPM包
make install DESTDIR=/tmp/bcc-install
fpm -s dir -t rpm -n bcc -v 0.25.0 -C /tmp/bcc-install -p /tmp/bcc.rpm usr
```

3. 安装生成的RPM包：

```bash
dnf install -y /tmp/bcc.rpm
```



#### 安装结束

#### 2.2 OPenEuler22.03中NFS的配置
##### 在 OpenEuler 22.03 上启用并启动 NFS 和 rpcbind 服务：

##### step1（客户端）：

首先在客户端上安装 NFS 工具：

```bash
dnf -y install nfs-utils
```

##### step2（服务端）：

1. 启动并查看 `rpcbind` 服务状态：

```bash
systemctl start rpcbind
systemctl status rpcbind
```

2. 启动并查看 `nfs-server` 服务状态：

```bash
systemctl start nfs-server
systemctl status nfs-server
```

3. 设置 `rpcbind` 和 `nfs-server` 服务开机自启：

```bash
systemctl enable rpcbind
systemctl enable nfs-server
```

4. 再次确认服务状态：

```bash
systemctl status rpcbind
systemctl status nfs-server
```



##### step3（服务端）：

1. 确保防火墙和 SELinux 关闭：

```bash
systemctl stop firewalld
systemctl disable firewalld
setenforce 0
sed -i 's/SELINUX=enforcing/SELINUX=disabled/' /etc/selinux/config
```

2. 安装 NFS 和相关工具：

```bash
dnf -y install nfs-utils
```

3. 配置 `/etc/exports` 文件：

```bash
echo "/media *(rw)" > /etc/exports #这条命令的效果是将/media目录配置为NFS导出的目录，并允许所有客户端以读写权限访问该目录
exportfs -a
```

4. 启动并启用 NFS 服务：

```bash
systemctl start rpcbind
systemctl enable rpcbind
systemctl start nfs-server
systemctl enable nfs-server
```

5. 检查 NFS 服务状态：

```bash
systemctl status rpcbind
systemctl status nfs-server
```

6. 确保 `/media` 目录的权限设置正确：

```bash
setfacl -m u:nobody:rwx /media/
getfacl /media/
```
7.设置ACL权限

```bash
setfacl -m u:KYLE（服务端的另一个被用来匿名映射的用户）:rwx /media/
```



##### step4（客户端）：

1. 安装 NFS 工具：

```bash
dnf -y install nfs-utils
```

2. 检查服务器上的共享目录：

```bash
showmount -e 192.168.232.130
```

3. 挂载 NFS 文件系统：

```bash
echo "192.168.232.130:/media /mnt nfs defaults,_netdev 0 0" >> /etc/fstab
mount -a
```

4. 验证挂载：

```bash
df -h
```

5. 测试文件创建和删除：
   在服务器端 `/media` 目录中创建文件：

```bash
cd /media/
touch abc
touch 123
ls
```

在客户端 `/mnt` 目录中查看并删除文件：

```bash
cd /mnt/
ls
rm -f abc
ls
```



##### 注：mount -t nfs SERVER:/path/to/sharedfs /path/to/mount_point为临时挂载
##### 编辑/etc/fstab文件为永久挂载

#### 2.3 客户端和服务端网络拓扑图
```
   +---------+          +---------+          +---------+
   |         |          |         |          |         |
   | 服务器   |---------|  交换机  |----------| 客户端   |
   |         |          |         |          |         |
   +---------+          +---------+          +---------+
       |                                          |
       |                                          |
 +------------+                             +------------+
 | user1.root |                             | root       |
 |(服务器配置)|                              |            |
 +------------+                             +------------+
 | user2.Kyle |                             | IP:        |
 | (id: 1000) |                             |192.168.0.103|
 |(匿名映射id)|                              |子网掩码:    |
 +------------+                             |255.255.255.0|
 | IP:        |                             +------------+
 |192.168.0.102|
 |子网掩码:   |
 |255.255.255.0|
 +------------+
```
### 3. eBPF程序

#### 3.1 eBPF程序概述

eBPF程序主要负责在内核态拦截和处理NFS请求，具体包括以下几个部分：
- **定义NFS请求和RPC消息头结构体**：用于解析NFS请求和RPC消息。
- **定义eBPF映射**：用于统计不同类型的NFS操作次数。
- **实现XDP程序**：用于在内核态处理NFS请求，包含对数据包的解析和处理逻辑。

#### 3.2 关键代码

```c
#include <uapi/linux/bpf.h>  // 包含BPF程序的基本定义
#include <uapi/linux/if_ether.h>  // 包含以太网头文件定义
#include <uapi/linux/ip.h>  // 包含IP头文件定义
#include <uapi/linux/tcp.h>  // 包含TCP头文件定义
#include <linux/in.h>  // 包含网络协议相关的定义

// 定义一个事件结构体，用于存储捕获到的数据
struct event_t {
    u64 ts;  // 时间戳，表示事件发生的时间
    u16 sport;  // 源端口
    u16 dport;  // 目的端口
    u32 saddr;  // 源IP地址
    u32 daddr;  // 目的IP地址
    u8 nfs_op;  // NFS操作码
    u8 user_space_flag;  // 标志是否需要用户态处理
    u8 alert;  // 安全警报标志
};

// 定义BPF哈希表和输出通道
BPF_PERF_OUTPUT(events);  // 用于向用户态传递事件
BPF_HASH(nfs_cache, u64, u8);  // 用于缓存NFS操作码
BPF_HASH(ip_access_count, u32, u64);  // 用于记录每个IP的访问次数
BPF_HASH(nfs_op_count, u32, u64);  // 用于记录每个NFS操作码的频率
BPF_HASH(user_space_ops_map, u32, u8);  // 用于配置哪些操作码需要用户态处理
BPF_HASH(permission_map, u32, u8);  // 用于配置每个NFS操作和IP的权限控制
BPF_HASH(nfs_cache_map, u64, struct event_t);  // 用于缓存完整的事件结构

// 一些常量定义
#define USER_SPACE_OPS { 34, 28 }  // 需要用户态处理的操作码列表
#define REMOVE_OP_CODE 28  // REMOVE操作的操作码
#define REMOVE_OP_OFFSET 0x00f9  // REMOVE操作码在数据包中的偏移量
#define MAX_ACCESS_THRESHOLD 1000  // IP访问频率阈值
#define HIGH_FREQ_THRESHOLD 50  // 操作码高频率阈值

// 处理网络数据包的函数
int handle_ingress(struct __sk_buff *skb) {
    struct ethhdr eth;  // 定义以太网头结构体
    // 从数据包中加载以太网头
    if (bpf_skb_load_bytes(skb, 0, &eth, sizeof(eth)) < 0) {
        bpf_trace_printk("Failed to load Ethernet header\\n");
        return -1;  // 加载失败，直接返回
    }

    // 只处理IP协议的数据包
    if (eth.h_proto != htons(ETH_P_IP)) {
        return 0;  // 非IP数据包，忽略
    }

    struct iphdr ip;  // 定义IP头结构体
    // 从数据包中加载IP头
    if (bpf_skb_load_bytes(skb, sizeof(eth), &ip, sizeof(ip)) < 0) {
        bpf_trace_printk("Failed to load IP header\\n");
        return -1;  // 加载失败，直接返回
    }

    // 只处理TCP协议的数据包
    if (ip.protocol != IPPROTO_TCP) {
        return 0;  // 非TCP数据包，忽略
    }

    struct tcphdr tcp;  // 定义TCP头结构体
    // 从数据包中加载TCP头
    if (bpf_skb_load_bytes(skb, sizeof(eth) + sizeof(ip), &tcp, sizeof(tcp)) < 0) {
        bpf_trace_printk("Failed to load TCP header\\n");
        return -1;  // 加载失败，直接返回
    }

    // 只处理目标端口为2049的数据包，即NFS服务端口
    if (tcp.dest != htons(2049)) {
        return 0;  // 非NFS数据包，忽略
    }

    // 定义操作码偏移量，用于读取NFS操作码
    int nfs_op_offset = 0x0101;
    u8 nfs_op;  // 定义NFS操作码变量
    // 从数据包中加载NFS操作码
    if (bpf_skb_load_bytes(skb, nfs_op_offset, &nfs_op, sizeof(nfs_op)) < 0) {
        bpf_trace_printk("Failed to load NFS operation code\\n");
        return -1;  // 加载失败，直接返回
    }

    // 特殊处理REMOVE操作码，可能存在位置偏移的情况
    if (nfs_op == 0) {
        u8 possible_remove_op;
        if (bpf_skb_load_bytes(skb, REMOVE_OP_OFFSET, &possible_remove_op, sizeof(possible_remove_op)) >= 0) {
            if (possible_remove_op == REMOVE_OP_CODE) {
                nfs_op = REMOVE_OP_CODE;  // 如果匹配，设置操作码为REMOVE
            }
        }
    }

    // 生成用于缓存的键值，基于源IP和TCP序列号
    u64 key = ((u64)ip.saddr << 32) | tcp.seq;
    u8 *cached_op = nfs_cache.lookup(&key);  // 查询缓存是否存在该操作码
    if (cached_op) {
        nfs_op = *cached_op;  // 如果缓存命中，使用缓存中的操作码
    } else {
        nfs_cache.update(&key, &nfs_op);  // 否则，更新缓存
    }

    // 查询user_space_ops_map，确定该操作是否需要用户态处理
    u32 op_key = nfs_op;
    u8 *user_space_flag_ptr = user_space_ops_map.lookup(&op_key);
    u8 user_space_flag = 0;  // 默认初始化为0，表示不需要用户态处理

    if (user_space_flag_ptr) {
        user_space_flag = *user_space_flag_ptr;  // 如果找到对应的操作码，则设置为需要用户态处理
    }

    // 更新IP访问次数计数
    u64 *count = ip_access_count.lookup(&ip.saddr);
    if (count) {
        *count += 1;  // 如果存在计数，增加访问次数
    } else {
        u64 initial_count = 1;
        ip_access_count.update(&ip.saddr, &initial_count);  // 否则，初始化计数
    }

    u8 alert = 0;  // 初始化警报标志
    // 如果访问次数超过阈值，触发警报
    if (count && *count > MAX_ACCESS_THRESHOLD) {
        alert = 1;
    }

    // 更新操作码频率计数
    u64 *op_count = nfs_op_count.lookup(&op_key);
    if (op_count) {
        *op_count += 1;  // 如果存在计数，增加操作码频率
    } else {
        u64 initial_count = 1;
        nfs_op_count.update(&op_key, &initial_count);  // 否则，初始化计数
    }

    // 如果操作码频率超过阈值，触发警报
    if (op_count && *op_count > HIGH_FREQ_THRESHOLD) {
        alert = 1;
    }

    // 检查权限控制，如果该操作被禁止，返回错误
    u32 perm_key = ((u32)ip.saddr << 16) | nfs_op;
    u8 *perm_flag = permission_map.lookup(&perm_key);
    if (perm_flag && *perm_flag == 0) {
        bpf_trace_printk("Permission denied for operation %d from IP %d\\n", nfs_op, ip.saddr);
        return -1;
    }

    // 创建事件结构体并填充数据
    struct event_t event = {};
    event.ts = bpf_ktime_get_ns();  // 获取事件发生的时间戳
    event.sport = tcp.source;  // 源端口
    event.dport = tcp.dest;  // 目的端口
    event.saddr = ip.saddr;  // 源IP地址
    event.daddr = ip.daddr;  // 目的IP地址
    event.nfs_op = nfs_op;  // NFS操作码
    event.user_space_flag = user_space_flag;  // 用户态处理标志
    event.alert = alert;  // 安全警报标志

    // 向用户态传递事件
    events.perf_submit(skb, &event, sizeof(event));

    // 更新缓存
    nfs_cache_map.update(&key, &event);

    return 0;  // 返回成功
}
```

### 4. 用户态程序

用户态程序主要负责加载、管理和监控eBPF程序，并与内核态程序进行交互。通过用户态程序，可以将eBPF程序加载到内核中，并实时监控NFS操作的统计数据。

#### 4.1 关键代码

```python
from bcc import BPF  # 导入BPF模块，用于与eBPF进行交互
import ctypes as ct  # 导入ctypes模块，用于定义C语言结构体
import socket  # 导入socket模块，用于IP地址处理
from struct import pack  # 导入pack函数，用于打包数据
import datetime  # 导入datetime模块，用于时间格式化
import json  # 导入json模块，用于日志输出时序列化数据
import subprocess  # 导入subprocess模块，用于执行系统命令

# 获取系统启动时间，用于计算事件的实际发生时间
# 参考资料来自：https://www.cnblogs.com/liujunjun/p/14764444.html
with open('/proc/stat') as f:
    for line in f:
        if line.startswith('btime'):
            btime = int(line.split()[1])
            break

# 定义eBPF程序，使用C语言编写的内核态代码
# 参考资料来自：https://coolshell.cn/articles/22320.html 和 https://github.com/iovisor/bcc/blob/master/docs/tutorial_bcc_python_developer.md 
# 和 https://wenku.csdn.net/answer/3684e69e7be142929925d0ca29ac3ef4 和 https://www.cnblogs.com/nmgxbc/p/5812377.html
b = BPF(text="""
#include <uapi/linux/bpf.h>  // 包含BPF程序的基本定义
#include <uapi/linux/if_ether.h>  // 包含以太网头文件定义
#include <uapi/linux/ip.h>  // 包含IP头文件定义
#include <uapi/linux/tcp.h>  // 包含TCP头文件定义
#include <linux/in.h>  // 包含网络协议相关的定义
#include <linux/pkt_cls.h>  // 包含用于TC的包分类定义

// 定义一个事件结构体，用于存储捕获到的数据
struct event_t {
    u64 ts;  // 时间戳，表示事件发生的时间
    u16 sport;  // 源端口
    u16 dport;  // 目的端口
    u32 saddr;  // 源IP地址
    u32 daddr;  // 目的IP地址
    u8 nfs_op;  // NFS操作码
    u8 user_space_flag;  // 标志是否需要用户态处理
    u8 alert_IP;  // IP安全警报标志
    u8 alert_OP;  // 操作安全警报标志
    u8 perm_flag; // 权限警报标志
};

// 定义BPF哈希表和输出通道
BPF_PERF_OUTPUT(events);  // 用于向用户态传递事件
BPF_HASH(nfs_cache, u64, u8);  // 用于缓存NFS操作码
BPF_HASH(ip_access_count, u32, u64);  // 用于记录每个IP的访问次数
BPF_HASH(nfs_op_count, u32, u64);  // 用于记录每个NFS操作码的频率
BPF_HASH(user_space_ops_map, u32, u8);  // 用于配置哪些操作码需要用户态处理
BPF_HASH(permission_map, u32, u8);  // 用于配置NFS操作的权限控制
BPF_HASH(nfs_cache_map, u64, struct event_t);  // 用于缓存完整的事件结构

// 一些常量定义
#define SETATTR_OP_CODE 34  // SETATTR操作的操作码
#define NFS_OP_OFFSET 0x00f9  // NFS操作码在数据包中一般情况下的偏移量
#define OTHER_OP_OFFSET 0x0101 // 一些别的操作码在数据包中的偏移量
#define MAX_ACCESS_THRESHOLD 1000  // IP访问频率阈值
#define HIGH_FREQ_THRESHOLD 50  // 操作码高频率阈值
#define WRITE_OP_CODE 38 // WRITE操作的操作码
#define CLOSE_OP_OFFSET 0x0111 // CLOSE操作的偏移量
#define OPEN_OP_CODE 18  // OPEN操作的操作码
#define REPLY_OP_OFFSET 0x00a1 // 回复操作的偏移量
#define RETURN_STATUS_OFFSET 0x0061 // 返回状态的偏移量
#define NFS4ERR_ROFS 30 // 只读文件系统错误码

// 处理网络数据包的XDP程序
// 参考资料：https://ebpf-docs.dylanreimerink.nl/linux/helper-function/bpf_skb_load_bytes/ 和 https://www.cnblogs.com/ink-white/p/16816464.html
int handle_xdp(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;  // 获取数据包结束的指针
    void *data = (void *)(long)ctx->data;  // 获取数据包开始的指针

    struct ethhdr *eth = data;  // 定义以太网头结构体
    // 检查以太网头是否完整
    if (data + sizeof(*eth) > data_end) {
        return XDP_PASS;  // 数据包不完整，直接放行
    }

    // 只处理IP协议的数据包
    if (eth->h_proto != htons(ETH_P_IP)) {
        return XDP_PASS;  // 非IP数据包，放行
    }

    struct iphdr *ip = data + sizeof(*eth);  // 定义IP头结构体
    // 检查IP头是否完整
    if (data + sizeof(*eth) + sizeof(*ip) > data_end) {
        return XDP_PASS;  // 数据包不完整，直接放行
    }

    // 只处理TCP协议的数据包
    if (ip->protocol != IPPROTO_TCP) {
        return XDP_PASS;  // 非TCP数据包，放行
    }

    struct tcphdr *tcp = (void *)ip + sizeof(*ip);  // 定义TCP头结构体
    // 检查TCP头是否完整
    if (data + sizeof(*eth) + sizeof(*ip) + sizeof(*tcp) > data_end) {
        return XDP_PASS;  // 数据包不完整，直接放行
    }

    // 只处理目标端口为2049的数据包，即NFS服务端口
    if (tcp->dest != htons(2049)) {
        return XDP_PASS;  // 非NFS数据包，放行
    }

    int nfs_op_offset = NFS_OP_OFFSET;  // 定义操作码偏移量
    u8 nfs_op;  // 定义NFS操作码变量
    // 检查操作码是否在数据包范围内
    if (data + nfs_op_offset + sizeof(nfs_op) > data_end) {
        return XDP_PASS;  // 操作码不在范围内，直接放行
    }

    // 从数据包中加载NFS操作码
    nfs_op = *(u8 *)(data + nfs_op_offset);

    if (nfs_op == 0) {
        // 检查CLOSE操作码是否在数据包范围内
        if (data + CLOSE_OP_OFFSET + sizeof(nfs_op) > data_end) {
            return XDP_PASS;  // 操作码不在范围内，直接放行
        }
        // 检查是否为CLOSE操作
        if (*(u8 *)(data + CLOSE_OP_OFFSET) == 4) {
            nfs_op = *(u8 *)(data + CLOSE_OP_OFFSET);  // 设置操作码为CLOSE
        } else {
            nfs_op = 0;  // 否则设置为0
        }
    }

    if (nfs_op == 0) {
        // 检查其他操作码是否在数据包范围内
        if (data + OTHER_OP_OFFSET + sizeof(nfs_op) > data_end) {
            return XDP_PASS;  // 操作码不在范围内，直接放行
        }
        // 从数据包中加载可能的其他操作码
        u8 possible_other_op = *(u8 *)(data + OTHER_OP_OFFSET);
        nfs_op = possible_other_op;
    }

    // 生成用于缓存的键值，基于源IP和TCP序列号
    u64 key = ((u64)ip->saddr << 32) | tcp->seq;
    u8 *cached_op = nfs_cache.lookup(&key);  // 查询缓存是否存在该操作码
    if (cached_op) {
        nfs_op = *cached_op;  // 如果缓存命中，使用缓存中的操作码
    } else {
        nfs_cache.update(&key, &nfs_op);  // 否则，更新缓存
    }

    // 查询user_space_ops_map，确定该操作是否需要用户态处理
    u32 op_key = (u32)nfs_op;
    u8 *user_space_flag_ptr = user_space_ops_map.lookup(&op_key);
    u8 user_space_flag = 0;  // 默认初始化为0，表示不需要用户态处理

    if (user_space_flag_ptr) {
        user_space_flag = *user_space_flag_ptr;  // 如果找到对应的操作码，则设置为需要用户态处理
    }

    // 更新IP访问次数计数
    u64 *count = ip_access_count.lookup(&ip->saddr);
    if (count) {
        *count += 1;  // 如果存在计数，增加访问次数
    } else {
        u64 initial_count = 1;
        ip_access_count.update(&ip->saddr, &initial_count);  // 否则，初始化计数
    }

    u8 alert_IP = 0;  // 初始化警报标志
    // 如果访问次数超过阈值，触发警报
    if (count && *count > MAX_ACCESS_THRESHOLD) {
        alert_IP = 1;
    }

    // 更新操作码频率计数
    u64 *op_count = nfs_op_count.lookup(&op_key);
    if (op_count) {
        *op_count += 1;  // 如果存在计数，增加操作码频率
    } else {
        u64 initial_count = 1;
        nfs_op_count.update(&op_key, &initial_count);  // 否则，初始化计数
    }

    u8 alert_OP = 0;
    // 如果操作码频率超过阈值，触发警报
    if (op_count && *op_count > HIGH_FREQ_THRESHOLD) {
        alert_OP = 1;
    }

    u8 permission_flag = 1;
    // 检查权限控制，如果该操作或IP被禁止，返回错误
    u8 *perm_flag = permission_map.lookup(&op_key);
    if (perm_flag && *perm_flag == 0) {
        permission_flag = *perm_flag;
        struct event_t event = {};
        event.ts = bpf_ktime_get_ns();  // 获取事件发生的时间戳
        event.sport = tcp->source;  // 源端口
        event.dport = tcp->dest;  // 目的端口
        event.saddr = ip->saddr;  // 源IP地址
        event.daddr = ip->daddr;  // 目的IP地址
        event.nfs_op = nfs_op;  // NFS操作码
        event.user_space_flag = user_space_flag;  // 用户态处理标志
        event.alert_IP = alert_IP;  // IP安全警报标志
        event.alert_OP = alert_OP;  // OP安全警报标志
        event.perm_flag = permission_flag; // 权限警报标志

        events.perf_submit(ctx, &event, sizeof(event));  // 向用户态传递事件

        // 无权限，直接阻止操作并记录日志
        return XDP_DROP;
    }

    // 创建事件结构体并填充数据
    struct event_t event = {};
    event.ts = bpf_ktime_get_ns();  // 获取事件发生的时间戳
    event.sport = tcp->source;  // 源端口
    event.dport = tcp->dest;  // 目的端口
    event.saddr = ip->saddr;  // 源IP地址
    event.daddr = ip->daddr;  // 目的IP地址
    event.nfs_op = nfs_op;  // NFS操作码
    event.user_space_flag = user_space_flag;  // 用户态处理标志
    event.alert_IP = alert_IP;  // IP安全警报标志
    event.alert_OP = alert_OP;  // OP安全警报标志
    event.perm_flag = permission_flag; // 权限警报标志

    events.perf_submit(ctx, &event, sizeof(event));  // 向用户态传递事件
    nfs_cache_map.update(&key, &event);  // 更新缓存

    return XDP_PASS;
}

""")

# 加载和附加XDP程序
fn_xdp = b.load_func("handle_xdp", BPF.XDP)  # 将eBPF函数附加到XDP（eXpress Data Path）上，用于高效处理数据包
b.attach_xdp("enp0s3", fn_xdp, 0)  # 将该eBPF程序附加到网络接口enp0s3

# 初始化 user_space_ops_map 和 permission_map
def init_user_space_ops_map():
    ops = [25]  # 需要用户态处理的操作码列表
    for op in ops:
        flag = ct.c_uint8(1)
        b["user_space_ops_map"].__setitem__(ct.c_uint32(op), flag)

def init_permission_map():
    write_op_code = 38  # WRITE操作的操作码
    perm_key = ct.c_uint32(write_op_code)
    zero = ct.c_uint8(0)
    b["permission_map"].__setitem__(perm_key, zero)  # 设置WRITE操作为无权限

init_user_space_ops_map()  # 初始化user_space_ops_map
init_permission_map()  # 初始化permission_map

# 定义用于处理事件的结构体
# 参考教程和资料：https://docs.python.org/3/library/ctypes.html
class Event(ct.Structure):
    _fields_ = [
        ("ts", ct.c_uint64),  # 时间戳
        ("sport", ct.c_uint16),  # 源端口
        ("dport", ct.c_uint16),  # 目的端口
        ("saddr", ct.c_uint32),  # 源IP地址
        ("daddr", ct.c_uint32),  # 目的IP地址
        ("nfs_op", ct.c_uint8),  # NFS操作码，通过抓包分析结构得到
        ("user_space_flag", ct.c_uint8),  # 用户态处理标志
        ("alert_IP", ct.c_uint8),  # IP安全警报标志
        ("alert_OP", ct.c_uint8),  # OP安全警报标志
        ("perm_flag", ct.c_uint8)  # 权限警报标志
    ]

# 将IP地址转换为字符串形式
# 参考资料：https://bitmingw.com/2018/05/06/get-ip-address-of-network-interface-in-python/ 和 https://blog.csdn.net/jackyzhousales/article/details/78036097
def ip_to_str(ip):
    return socket.inet_ntoa(pack("!I", ip))

# 将NFS操作码转换为可读的字符串形式
# 参考资料：https://www.rfc-editor.org/rfc/rfc7530#page-12
def nfs_op_to_str(nfs_op):
    nfs_ops = {
        0: "NULL",
        1: "COMPOUND",
        3: "ACCESS",
        4: "CLOSE",
        5: "COMMIT",
        6: "CREATE",
        7: "DELEGPURGE",
        8: "DELEGRETURN",
        9: "GETATTR",
        10: "GETFH",
        11: "LINK",
        12: "LOCK",
        13: "LOCKT",
        14: "LOCKU",
        15: "LOOKUP",
        16: "LOOKUPP",
        17: "NVERIFY",
        18: "OPEN",
        19: "OPENATTR",
        20: "OPEN_CONFIRM",
        21: "OPEN_DOWNGRADE",
        22: "PUTFH",
        23: "PUTPUBFH",
        24: "PUTROOTFH",
        25: "READ",
        26: "READDIR",
        27: "READLINK",
        28: "REMOVE",
        29: "RENAME",
        30: "RENEW",
        31: "RESTOREFH",
        32: "SAVEFH",
        33: "SECINFO",
        34: "SETATTR",
        35: "SETCLIENTID",
        36: "SETCLIENTID_CONFIRM",
        37: "VERIFY",
        38: "WRITE",
        39: "RELEASE_LOCKOWNER",
        40: "BACKCHANNEL_CTL",
        41: "BIND_CONN_TO_SESSION",
        42: "EXCHANGE_ID",
        43: "CREATE_SESSION",
        44: "DESTROY_SESSION",
        45: "FREE_STATEID",
        46: "GET_DIR_DELEGATION",
        47: "GETDEVICEINFO",
        48: "GETDEVICELIST",
        49: "LAYOUTCOMMIT",
        50: "LAYOUTGET",
        51: "LAYOUTRETURN",
        52: "SECINFO_NO_NAME",
        53: "SEQUENCE",
        54: "SET_SSV",
        55: "TEST_STATEID",
        56: "WANT_DELEGATION",
        57: "DESTROY_CLIENTID",
        58: "RECLAIM_COMPLETE",
    }
    return nfs_ops.get(nfs_op, "Unknown")  # 返回操作码对应的字符串，如果找不到则返回"Unknown"

# 将时间戳转换为可读的日期时间格式
# 参考资料：https://www.runoob.com/python3/python-timstamp-str.html
def timestamp_to_datetime(ts):
    event_time = btime + ts / 1e9  # 将时间戳转换为秒级时间
    dt = datetime.datetime.fromtimestamp(event_time)  # 创建datetime对象
    return dt.strftime("%Y-%m-%d %H:%M:%S")  # 返回格式化的时间字符串

# 将事件记录到日志文件中
# 参考资料：https://blog.csdn.net/qq_46293423/article/details/105785007
def log_event_to_file(event):
    log_entry = {
        "timestamp": timestamp_to_datetime(event.ts),  # 时间戳
        "saddr": ip_to_str(socket.ntohl(event.saddr)),  # 源IP地址
        "daddr": ip_to_str(socket.ntohl(event.daddr)),  # 目的IP地址
        "sport": socket.ntohs(event.sport),  # 源端口
        "dport": socket.ntohs(event.dport),  # 目的端口
        "nfs_op": nfs_op_to_str(event.nfs_op),  # NFS操作码
        "user_space_flag": event.user_space_flag,  # 用户态处理标志
        "alert_IP": event.alert_IP,  # IP安全警报标志
        "alert_OP": event.alert_OP,  # OP安全警报标志
        "perm_flag": event.perm_flag  # 权限警报标志
    }
    # 以追加模式打开日志文件，并写入事件日志
    with open("/var/log/ebpf_nfs.log", "a") as log_file:
        log_file.write(json.dumps(log_entry) + "\n")

# 处理捕获到的事件
# 参考资料：https://www.cnblogs.com/imteck4713/p/18258400 
def print_event(cpu, data, size):
    event = ct.cast(data, ct.POINTER(Event)).contents  # 将数据转换为Event结构体，得到一个包含事件信息的 event 对象
    log_event_to_file(event)  # 记录事件到日志文件
    saddr = ip_to_str(socket.ntohl(event.saddr))  # 转换源IP地址
    daddr = ip_to_str(socket.ntohl(event.daddr))  # 转换目的IP地址
    sport = socket.ntohs(event.sport)  # 转换源端口
    dport = socket.ntohs(event.dport)  # 转换目的端口
    nfs_op = nfs_op_to_str(event.nfs_op)  # 转换NFS操作码
    timestamp = timestamp_to_datetime(event.ts)  # 转换时间戳
    # 根据事件标志打印不同的日志信息
    if event.perm_flag == 0:
        print(f"时间: {timestamp}, 源IP为: {saddr}的NFS操作: {nfs_op} 没有访问权限")
    else:
        if event.alert_IP:
            print(f"时间: {timestamp}, 源IP: {saddr}, 目的IP: {daddr}, NFS操作: {nfs_op} - 警报: IP访问频率异常!")
        if event.alert_OP:
            print(f"时间: {timestamp}, 源IP: {saddr}, 目的IP: {daddr}, NFS操作: {nfs_op} - 警报: 操作频率异常!")
        elif event.user_space_flag:
            print(f"时间: {timestamp}, 源IP: {saddr}, 目的IP: {daddr}, 源端口: {sport}, 目的端口: {dport}, NFS操作: {nfs_op} (需要用户态处理)")
        else:
            print(f"时间: {timestamp}, 源IP: {saddr}, 目的IP: {daddr}, 源端口: {sport}, 目的端口: {dport}, NFS操作: {nfs_op} (内核态处理)")

# 打开perf缓冲区，用于捕获事件
# 参考资料：https://www.cnblogs.com/lianyihong/p/17922818.html
b["events"].open_perf_buffer(print_event)

print("eBPF程序已加载并附加。正在监控NFS请求...")

# 加载和附加TC程序
tc_prog = "/root/桌面/ebpf_nfs.o"
dev = "enp0s3"

# 删除已有的TC qdisc，避免冲突
subprocess.call(f"tc qdisc del dev {dev} clsact", shell=True)
# 添加TC qdisc
subprocess.call(f"tc qdisc add dev {dev} clsact", shell=True)
# 添加TC过滤器并附加BPF程序
subprocess.call(f"tc filter add dev {dev} ingress bpf da obj {tc_prog} sec classifier", shell=True)

# 持续轮询缓冲区以处理事件
# 参考资料：https://eunomia.dev/zh/tutorials/bcc-documents/reference_guide/#_1
while True:
    try:
        b.perf_buffer_poll()  # 轮询缓冲区
    except KeyboardInterrupt:
        subprocess.call(f"tc qdisc del dev {dev} clsact", shell=True)
        exit()  # 捕获键盘中断信号后退出程序

```
```c
#include <linux/bpf.h>  // 包含eBPF程序的基本定义
#include <linux/if_ether.h>  // 包含以太网头文件定义
#include <linux/ip.h>  // 包含IP头文件定义
#include <linux/tcp.h>  // 包含TCP头文件定义
#include <linux/in.h>  // 包含网络协议相关的定义
#include <linux/pkt_cls.h>  // 包含用于TC的包分类定义
#include <bpf/bpf_helpers.h>  // 包含BPF辅助函数的定义

#define REPLY_OP_OFFSET 0x00a1  // 回复操作码在数据包中的偏移量
#define RETURN_STATUS_OFFSET 0x0061  // 返回状态码在数据包中的偏移量
#define WRITE_OP_CODE 38  // WRITE操作码
#define NFS4ERR_ROFS 30  // NFS只读文件系统错误码

// 定义一个BPF哈希表，用于存储权限控制信息
struct {
    __uint(type, BPF_MAP_TYPE_HASH);  // 定义哈希表类型为BPF_MAP_TYPE_HASH
    __uint(max_entries, 1024);  // 最大条目数为1024
    __type(key, __u32);  // 键的类型为__u32
    __type(value, __u8);  // 值的类型为__u8
} permission_map SEC(".maps");  // 定义哈希表的名称为permission_map，并放置在maps段

// 定义一个eBPF程序，用于处理TC（Traffic Control）数据包
SEC("classifier")
int handle_tc(struct __sk_buff *skb) {
    void *data_end = (void *)(long)skb->data_end;  // 获取数据包结束的指针
    void *data = (void *)(long)skb->data;  // 获取数据包开始的指针

    struct ethhdr *eth = data;  // 定义以太网头结构体
    // 检查以太网头是否完整
    if (data + sizeof(*eth) > data_end) {
        return TC_ACT_OK;  // 数据包不完整，直接放行
    }

    // 只处理IP协议的数据包
    if (eth->h_proto != __constant_htons(ETH_P_IP)) {
        return TC_ACT_OK;  // 非IP数据包，放行
    }

    struct iphdr *ip = data + sizeof(*eth);  // 定义IP头结构体
    // 检查IP头是否完整
    if (data + sizeof(*eth) + sizeof(*ip) > data_end) {
        return TC_ACT_OK;  // 数据包不完整，直接放行
    }

    // 只处理TCP协议的数据包
    if (ip->protocol != IPPROTO_TCP) {
        return TC_ACT_OK;  // 非TCP数据包，放行
    }

    struct tcphdr *tcp = (void *)ip + sizeof(*ip);  // 定义TCP头结构体
    // 检查TCP头是否完整
    if (data + sizeof(*eth) + sizeof(*ip) + sizeof(*tcp) > data_end) {
        return TC_ACT_OK;  // 数据包不完整，直接放行
    }

    // 只处理源端口为2049的数据包，即NFS服务器端口
    if (tcp->source != __constant_htons(2049)) {
        return TC_ACT_OK;  // 非NFS数据包，放行
    }

    __u8 nfs_op;  // 定义NFS操作码变量
    int reply_op_offset = REPLY_OP_OFFSET;  // 设置回复操作码的偏移量
    // 检查操作码是否在数据包范围内
    if (data + reply_op_offset + sizeof(nfs_op) > data_end) {
        return TC_ACT_OK;  // 操作码不在范围内，直接放行
    }

    // 从数据包中加载NFS操作码
    nfs_op = *(__u8 *)(data + reply_op_offset);

    // 检查是否为WRITE操作码
    if (nfs_op == WRITE_OP_CODE) {
        __u32 op_key = (__u32)nfs_op;  // 定义操作码的键值
        // 查询permission_map，确定该操作是否被禁止
        __u8 *perm_flag = bpf_map_lookup_elem(&permission_map, &op_key);
        if (perm_flag && *perm_flag == 0) {
            __u32 *status_code = (__u32 *)(data + RETURN_STATUS_OFFSET);  // 定义状态码指针
            *status_code = __constant_htonl(NFS4ERR_ROFS);  // 修改返回状态码为NFS4ERR_ROFS（只读文件系统错误）
        }
    }

    return TC_ACT_OK;  // 放行数据包
}

// 定义eBPF程序的许可证
char __license[] SEC("license") = "GPL";

```
### 5. 系统框架设计

#### 5.1 系统架构图

```
                       +---------------------------+
                       |       用户态程序          |
                       | - 加载 eBPF 程序          |
                       | - 初始化映射              |
                       | - 捕获和处理事件          |
                       +-----------|---------------+
                                   |
                                   |
                       +-----------V---------------+
                       |       内核态 eBPF 程序    |
                       | - XDP 程序                |
                       |   - 预处理数据包          |
                       |   - 统计和缓存信息        |
                       | - TC 程序                 |
                       |   - 检查权限和修改状态码  |
                       +-----------|---------------+
                                   |
                                   |
                       +-----------V---------------+
                       |       内核态映射          |
                       | - 权限控制映射            |
                       | - 统计和缓存映射          |
                       +---------------------------+
                                   |
                                   |
                       +-----------V---------------+
                       |       网络接口            |
                       | - 接收和发送数据包        |
                       +---------------------------+
                                   |
                                   |
                       +-----------V---------------+
                       |       NFS 服务            |
                       | - 处理网络文件系统请求    |
                       +---------------------------+


```

#### 5.2 主要模块和功能

##### **主要模块**

1. **用户态模块**
   - **BPF程序加载器**
   - **事件处理器**
   - **日志模块**
   - **监控模块**

2. **内核态模块**
   - **eBPF包过滤器**
   - **NFS操作检测**
   - **缓存与权限管理**

##### **功能概述**

##### **1. 用户态模块**

##### **BPF程序加载器**

- **功能**：加载和附加eBPF程序到网络接口。
- **主要职责**：
  - 使用BPF库加载eBPF代码。
  - 将加载的eBPF程序附加到指定的网络接口上。

##### **事件处理器**

- **功能**：处理从内核态传递过来的事件。
- **主要职责**：
  - 定义事件结构体，用于接收和解析内核态传递的事件数据。
  - 处理接收到的事件，将其转换为可读形式，并传递给日志模块和监控模块。

##### **日志模块**

- **功能**：记录和管理日志文件。
- **主要职责**：
  - 将处理后的事件数据记录到日志文件中，以追加模式存储，确保日志不会被覆盖。
  - 格式化日志条目为JSON格式，便于后续分析和处理。

##### **监控模块**

- **功能**：实时输出操作和警报信息。
- **主要职责**：
  - 根据事件的内容和标志（如警报标志、用户态处理标志等），将重要信息输出到控制台。
  - 提供实时监控功能，便于管理员及时了解系统状态和安全事件。

##### **2. 内核态模块**

##### **eBPF包过滤器**

- **功能**：捕获并处理网络数据包。
- **主要职责**：
  - 通过附加到网络接口的eBPF程序，捕获流入的网络数据包。
  - 解析数据包，提取以太网头、IP头和TCP头信息。

##### **NFS操作检测**

- **功能**：检测和处理NFS操作。
- **主要职责**：
  - 从数据包中提取NFS操作码，并进行初步处理。
  - 对特定的NFS操作码（如REMOVE操作）进行特殊处理，以确保正确解析。

##### **缓存与权限管理**

- **功能**：管理NFS操作的缓存与权限控制。
- **主要职责**：
  - 维护NFS操作码和事件的缓存，提高处理效率。
  - 记录IP访问次数和操作码频率，监控高频操作和异常访问。
  - 根据预定义的权限规则，检查并阻止未经授权的NFS操作。

##### 功能详细说明**

##### **1. 捕获和处理网络数据包**

- **捕获网络数据包**：通过eBPF程序附加到网络接口，捕获流入的所有数据包。
- **解析数据包**：从数据包中提取以太网头、IP头和TCP头信息，仅处理符合NFS协议的数据包。

##### **2. NFS操作检测和处理**

- **提取NFS操作码**：从数据包中提取NFS操作码，并根据预定义规则进行处理。
- **特殊处理REMOVE操作**：对可能存在位置偏移的REMOVE操作进行特殊处理，确保正确解析。

##### **3. 缓存管理和权限控制**

- **缓存NFS操作**：将NFS操作码和事件结构体缓存，减少重复解析的开销。
- **记录访问频率**：维护每个IP的访问次数和操作码的使用频率，监控异常行为。
- **权限检查**：根据预定义的权限规则，检查并阻止未经授权的操作，提升系统安全性。

##### **4. 事件传递和处理**

- **传递事件到用户态**：通过`perf_event`机制，将处理后的事件传递到用户态。
- **用户态事件处理**：在用户态解析事件数据，并根据其内容进行日志记录和实时监控输出。

##### **5. 日志记录和监控输出**

- **记录事件日志**：将解析后的事件数据格式化为JSON，并追加到日志文件中。
- **实时监控输出**：根据事件内容，实时输出重要信息（如警报、用户态处理标志等）到控制台，便于管理员及时了解系统状态。
#### 5.3 关键技术

1. **eBPF（Extended Berkeley Packet Filter）**：用于在内核态捕获和处理网络数据包，特别是解析和监控NFS操作。

2. **BCC（BPF Compiler Collection）库**：在用户态加载和管理eBPF程序，与内核态进行交互，接收并处理事件数据。

3. **NFS协议处理**：从捕获的TCP数据包中提取并解析NFS操作码，监控和记录关键操作。

4. **性能优化与安全监控**：使用eBPF哈希表缓存操作码和事件，提高处理效率；通过频率计数和权限检查实现安全监控。

5. **日志记录与实时监控**：在用户态将事件记录到日志文件，并实时输出重要警报和操作信息，便于系统监控和审计。

### 6. 总结

通过以上系统框架设计，可以有效地利用eBPF技术增强NFS的性能和安全性。在内核态处理部分NFS请求，减少用户态处理的开销，从而提高系统的响应速度和整体性能。同时，通过实时监控和统计NFS操作，可以增强系统的安全性，防范潜在的安全威胁。
</details>
<details><summary>4. 开发计划</summary>
为确保基于eBPF的增强型网络文件系统的顺利开发和实现，我们将开发计划分为以下几个阶段，每个阶段包括具体的任务和时间安排。

### 第一阶段：需求分析和技术调研（3天）

1. **任务**
   - 明确项目需求和目标
   - 详细分析比赛题目，确定技术难点和关键点
   - 调研eBPF和NFS的相关技术资料，学习基本用法和案例

2. **时间安排**
   - 第1天至第3天：需求分析和技术调研

### 第二阶段：系统设计（4天）

1. **任务**
   - 设计系统架构和模块划分
   - 制定详细的技术方案，包括eBPF程序和用户态程序的设计
   - 撰写系统设计文档，确定接口和数据结构

2. **时间安排**
   - 第4天至第7天：系统设计和文档撰写

### 第三阶段：eBPF程序开发（7天）

1. **任务**
   - 编写eBPF程序，实现NFS请求的拦截和处理逻辑
   - 测试和调试eBPF程序，确保其功能正确性和稳定性

2. **时间安排**
   - 第8天至第14天：eBPF程序开发与调试

### 第四阶段：用户态程序开发（4天）

1. **任务**
   - 编写用户态程序，实现eBPF程序的加载、管理和监控
   - 测试和调试用户态程序，确保其功能正确性和稳定性

2. **时间安排**
   - 第15天至第18天：用户态程序开发与调试

### 第五阶段：集成测试和性能优化（8天）

1. **任务**
   - 进行系统的集成测试，验证eBPF程序和用户态程序的协同工作
   - 优化eBPF程序的性能，确保系统在高负载下的稳定性
   - 进行安全性测试，验证系统的安全防护能力

2. **时间安排**
   - 第19天至第26天：集成测试、性能优化和安全性测试

### 第六阶段：文档撰写和项目总结（4天）

1. **任务**
   - 撰写项目文档，包括技术方案、测试报告、使用说明等
   - 总结项目经验，整理和提交项目成果
   - 准备比赛答辩材料

2. **时间安排**
   - 第27天至第30天：文档撰写和项目总结

### 总结

本开发计划详细划分了每个阶段的任务和时间安排，确保在一个月内高效完成基于eBPF的增强型网络文件系统的开发。通过严格执行开发计划，可以保证项目的质量和进度，最终实现一个高效、安全的网络文件系统。
</details>
<details><summary>5. 比赛过程中的重要进展</summary>
在一个月的开发周期中，项目团队经历了多个关键阶段，取得了若干重要进展，确保了项目的顺利推进和目标的实现。以下是比赛过程中各阶段的重要进展：

### 第一阶段：需求分析和技术调研

- **需求明确**：项目团队详细分析了比赛题目，明确了项目的需求和目标，制定了具体的实施计划。
- **技术调研**：团队成员通过查阅文献和案例，深入了解了eBPF和NFS的相关技术，掌握了eBPF程序的基本编写和NFS请求的处理逻辑，为后续开发打下了坚实基础。

### 第二阶段：系统设计和虚拟机的ebpf及nfs配置

- **系统架构设计**：项目团队设计了系统的整体架构，明确了各模块的功能和接口，确保了系统设计的完整性和可行性。
- **技术方案制定**：制定了详细的技术方案，包括eBPF程序和用户态程序的设计，确定了关键技术点和数据结构，撰写了系统设计文档。
- **虚拟机ebpf及nfs系统的配置**：配置并测试客户端和服务端能正常通信和进行nfs操作的请求及读取，分析nfs的请求数据包，为写代码做准备。

### 第三阶段：eBPF程序开发

- **eBPF程序编写**：团队成员成功编写了eBPF程序，实现了NFS请求的拦截和处理逻辑，并在内核态对NFS操作进行了统计和分析。
- **功能测试和调试**：通过一系列测试和调试，验证了eBPF程序的功能和稳定性，确保了程序能够在高负载下稳定运行。

### 第四阶段：用户态程序开发

- **用户态程序开发**：编写了用户态程序，实现了eBPF程序的加载、管理和监控功能，确保了用户态和内核态的协同工作。
- **功能测试和调试**：对用户态程序进行了测试和调试，但是由于环境冲突问题，python程序调用ebpf程序出现问题，导致开发停滞。

### 第五阶段：集成测试和性能优化

- **集成测试**：团队进行了系统的集成测试，验证了eBPF程序和用户态程序的协同工作，确保了系统能够正确处理和统计NFS请求。
- **性能优化**：通过优化eBPF程序的代码和数据结构，提高了系统在高负载下的性能，显著减少了用户态和内核态之间的上下文切换，提高了NFS的响应速度。
- **安全性测试**：利用eBPF的监测能力，对NFS的行为进行了详细的统计和分析，验证了系统的安全性，防范了潜在的安全威胁。

### 主要成就和里程碑

- **系统架构设计完成和虚拟机配置完成**：在第一周内完成了系统的整体架构设计和技术方案制定，配置并测试了虚拟机的运行。
- **eBPF程序开发成功**：在第二周内完成了eBPF程序的编写和初步测试，实现了NFS请求的拦截和处理。
- **用户态程序集成**：在第三周内完成了用户态程序的开发和集成测试，但是测试由于环境问题没成功。
- **系统性能优化**：在第四周内完成了系统的性能优化和安全性测试，显著提高了系统的响应速度和安全性。

通过以上各阶段的重要进展和成就，项目团队初步成功完成基于eBPF的增强型网络文件系统的开发，但有问题存在。
</details>
<details><summary>6. 系统测试情况</summary>
经过测试，代码可以正常执行相应的功能，具体测试如下：

**1.客户端执行脚本进行频繁地nfs操作：**

```
#!/bin/bash

# 配置NFS服务器IP地址和共享目录
NFS_SERVER="192.168.0.102"  # NFS服务器的IP地址
NFS_SHARE="/media"  # NFS服务器上共享的目录路径
MOUNT_POINT="/mnt"  # 本地挂载点，用于访问NFS共享

# 创建挂载点目录
mkdir -p $MOUNT_POINT  # 使用-p选项确保目录存在，若不存在则创建

# 挂载NFS共享目录到本地
mount -t nfs $NFS_SERVER:$NFS_SHARE $MOUNT_POINT
# -t nfs：指定文件系统类型为NFS
# $NFS_SERVER:$NFS_SHARE：指定NFS服务器及共享目录路径
# $MOUNT_POINT：指定本地的挂载点

# 模拟多次文件操作（创建、写入、读取、删除）
for i in {1..2000}  # 循环2000次，模拟大量的NFS操作
do
    touch $MOUNT_POINT/testfile_$i  # 在NFS挂载目录中创建一个空文件
    echo "This is test file $i" > $MOUNT_POINT/testfile_$i  # 写入测试内容到文件
    cat $MOUNT_POINT/testfile_$i > /dev/null  # 读取文件内容，并将输出重定向到空设备（模拟文件读取）
    rm -f $MOUNT_POINT/testfile_$i  # 删除该测试文件
done

# 卸载NFS共享目录
umount $MOUNT_POINT  # 卸载NFS挂载的目录

# 删除本地挂载点目录
rmdir $MOUNT_POINT  # 删除本地的挂载点目录（仅在目录为空时有效）
```


**在服务端的输出结果为：**

```
[root@OpenEuler-server 桌面]# python3 ebpf_nfs.py
eBPF程序已加载并附加。正在监控NFS请求...
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READDIR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: RECLAIM_COMPLETE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:06, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: WRITE (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: READ (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, NFS操作: GETATTR - 警报: 操作或访问频率异常!
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: Unknown (内核态处理)
时间: 2024-07-31 23:38:07, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 771, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
```

并且在/var/log/ebpf_nfs.log这个目录中存储了一个log文件来记录nfs请求操作的情况日志，类似如下结果：
```
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "READDIR", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "Unknown", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "RECLAIM_COMPLETE", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "OPEN", "user_space_flag": 1, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "SETATTR", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "GETATTR", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "OPEN", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "WRITE", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "GETATTR", "user_space_flag": 23, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "OPEN", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "READ", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "GETATTR", "user_space_flag": 31, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "REMOVE", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "OPEN", "user_space_flag": 183, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "SETATTR", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "GETATTR", "user_space_flag": 0, "alert": 0}
{"timestamp": "2024-07-31 21:57:42", "saddr": "192.168.0.103", "daddr": "192.168.0.102", "sport": 771, "dport": 2049, "nfs_op": "OPEN", "user_space_flag": 0, "alert": 0}
```

限制WRITE操作后为
```
[root@OpenEuler-server 桌面]# python3 ebpf_nfs.py
eBPF程序已加载并附加。正在监控NFS请求...
Error: Invalid handle.
libbpf: DATASEC '.maps' not found.
ERROR: opening BPF object file failed
Unable to load program
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: GETATTR (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: SETATTR (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: CLOSE (内核态处理)
时间: 2024-08-15 19:54:33, 源IP: 192.168.0.103, 目的IP: 192.168.0.102, 源端口: 864, 目的端口: 2049, NFS操作: OPEN (内核态处理)
时间: 2024-08-15 19:54:33, 源IP为: 192.168.0.103的NFS操作: WRITE 没有访问权限
时间: 2024-08-15 19:54:33, 源IP为: 192.168.0.103的NFS操作: WRITE 没有访问权限

```
</details>
<details><summary>7. 遇到的主要问题和解决方法</summary>
在开发基于eBPF的增强型网络文件系统的过程中，我们遇到了许多挑战和问题。通过团队的共同努力，逐步解决了这些问题，确保了项目的顺利进行。以下是开发过程中遇到的主要问题及其解决方法：

### 1. eBPF程序复杂性高

**问题**：
编写和调试eBPF程序较为复杂，需要处理内核态和用户态之间的通信，并确保在内核态高效执行代码。

**解决方法**：
- **深入学习eBPF技术**：团队成员通过查阅大量文献和教程，深入学习eBPF的基础知识和高级应用，掌握了eBPF程序的编写技巧。
- **使用bcc工具集**：借助bcc（BPF Compiler Collection）工具集，简化eBPF程序的编写和调试过程，提高开发效率。
- **代码分层设计**：将eBPF程序的功能进行分层设计，模块化实现各个功能，提高代码的可读性和可维护性。

### 2. 数据包解析复杂

**问题**：
在内核态解析网络数据包涉及多个协议层（以太网、IP、TCP、NFS），需要准确解析每一层的数据结构，并确保数据包解析的正确性和效率。

**解决方法**：
- **逐层解析**：利用tcpdump和wireshark工具抓包，按照网络协议的层次结构，逐层解析数据包，确保每一层的数据结构解析正确。
- **添加边界检查**：在解析每一层的数据结构时，添加严格的边界检查，防止越界访问，确保数据包解析的安全性和稳定性。
- **使用现有例子**：参考现有的eBPF程序和网络数据包解析例子，学习并借鉴其中的实现方法，减少重复工作和潜在错误。

### 3. 内核态与用户态通信

#### **1. 事件数据传递问题**

**问题**：如何将内核态捕获的事件数据传递到用户态进行处理和记录。

**解决办法**：

- 使用 `BPF_PERF_OUTPUT` 定义一个性能事件输出通道 (`events`)，用于将内核态捕获的事件数据传递到用户态。
- 在内核态中，使用 `events.perf_submit` 将结构化的事件数据提交到用户态。
- 在用户态，使用 `open_perf_buffer` 打开性能事件缓冲区，并通过回调函数 `print_event` 来处理传递过来的事件数据。

#### **2. 数据格式与结构体匹配问题**

**问题**：在内核态和用户态之间传递数据时，如何确保数据格式和结构体匹配。

**解决办法**：

- 在内核态定义一个事件结构体 `struct event_t`，用于存储要传递的事件数据。
- 在用户态使用 `ctypes` 模块定义与内核态相同的结构体 `Event`，确保数据格式一致性。
- 使用 `ct.cast` 函数将传递的二进制数据转换为用户态结构体类型，确保数据能够正确解析和使用。

#### **3. 数据包处理与过滤问题**

**问题**：如何在内核态高效地捕获和过滤网络数据包，仅处理与NFS相关的包。

**解决办法**：

- 使用 eBPF 程序附加到指定的网络接口，过滤和解析 TCP/IP 数据包。
- 在内核态中，通过分析以太网头、IP头、TCP头等层次结构，确保只处理目标端口为 2049 (NFS) 的数据包。
- 对特殊操作码（如 `REMOVE` 操作码）的偏移量进行特定处理，以确保正确解析。

#### **4. 性能与频率控制问题**

**问题**：如何在内核态中高效地处理频繁出现的操作，同时避免重复解析带来的性能开销。

**解决办法**：

- 使用 eBPF 哈希表（如 `nfs_cache`, `ip_access_count`, `nfs_op_count`）来缓存操作码、记录访问频率等，避免重复解析和统计，提高处理性能。
- 通过设置频率阈值（如 `MAX_ACCESS_THRESHOLD`, `HIGH_FREQ_THRESHOLD`）和权限控制（`permission_map`）来监控和控制异常操作频率，触发安全警报。

#### **5. 日志记录与实时监控问题**

**问题**：如何在用户态高效地记录和监控从内核态传递过来的事件数据。

**解决办法**：

- 在用户态，使用 `log_event_to_file` 函数将事件数据格式化为 JSON 并记录到日志文件中，以便后续分析和审计。
- 通过 `print_event` 函数实时解析并输出事件信息，提供实时监控功能，帮助系统管理员及时了解系统状态和安全事件。

### 4. 性能优化

**问题**：

- **高频操作的处理效率**：NFS操作在高频环境下的处理可能会造成内核态与用户态之间的瓶颈，尤其是在频繁的NFS操作请求下，系统性能可能受到影响。
- **重复操作的冗余处理**：每次处理NFS请求时，如果不对常见的操作进行缓存和复用，可能会导致不必要的重复计算，浪费系统资源。

**解决方案**：

- **操作码缓存**：引入`nfs_cache`哈希表，用于缓存NFS操作码。通过缓存机制，减少对相同操作的重复解析和处理，提升整体处理效率。
- **频率控制**：通过`nfs_op_count`哈希表记录每种NFS操作码的调用频率，避免高频操作对系统的过度占用。设置了频率阈值`HIGH_FREQ_THRESHOLD`，当某一操作超过该阈值时，系统会触发警报，防止单一操作频繁占用系统资源。
- **事件结构体缓存**：使用`nfs_cache_map`缓存完整的事件结构体，从而减少内核态与用户态之间不必要的数据传递，优化系统性能。

### 5. 安全性问题

**问题**：

- **未经授权的访问**：NFS操作可能存在未经授权的访问，特别是敏感操作如删除文件或获取文件属性的操作，若不加以限制，可能导致系统安全问题。
- **频繁访问的风险**：特定IP地址或操作码频繁访问可能暗示恶意行为，如DDoS攻击或恶意数据篡改。

**解决方案**：

- **权限控制**：通过`permission_map`哈希表对NFS操作进行权限检查。针对每个操作码和IP地址组合，定义了具体的权限策略。若某操作被禁止，则该请求被阻止，确保系统操作的安全性。
- **访问次数监控**：引入`ip_access_count`哈希表记录每个IP的访问次数，结合`MAX_ACCESS_THRESHOLD`阈值，监控并限制单个IP的频繁访问行为。一旦某个IP超过访问阈值，系统会触发警报，防止潜在的恶意访问。
- **安全警报机制**：系统在检测到异常访问或频繁操作时，设置了`alert`标志，通过事件传递机制，将警报信息传递到用户态，及时向管理员报告潜在的安全威胁。

</details>
<details><summary>8. 分工和协作</summary>
在开发基于eBPF的增强型网络文件系统的过程中，我们团队共两名成员，分别负责不同的模块和任务，通过紧密协作确保项目的顺利进行和高质量完成。以下是具体的分工和协作情况：

### 成员A（林俊烨）：主要负责eBPF程序开发

**任务分工**：
1. **需求分析和技术调研**：
   - 分析比赛题目，明确需求和技术难点。
   - 调研eBPF和NFS相关技术，学习基本用法和案例。
   
2. **系统设计**：
   - 参与系统架构设计，负责eBPF程序部分的设计。
   - 确定eBPF程序的技术方案和数据结构。

3. **eBPF程序开发**：
   - 编写eBPF程序，实现NFS请求的拦截和处理逻辑。
   - 负责eBPF程序的测试和调试，确保其功能正确性和稳定性。
   - 优化eBPF程序的性能，提高系统响应速度。

4. **性能优化和安全性测试**：
   - 对eBPF程序进行性能优化，减少用户态与内核态之间的上下文切换。
   - 进行安全性测试，确保eBPF程序的安全性和稳定性。

**协作方式**：
- 与成员B共同参与系统架构设计和需求分析。
- 定期与成员B交流eBPF程序开发中的问题和解决方案，共同优化系统性能。
- 通过代码评审和测试结果共享，确保eBPF程序的高质量实现。

### 成员B（耿杨）：主要负责用户态程序开发

**任务分工**：
1. **需求分析和技术调研**：
   - 分析比赛题目，明确需求和技术难点。
   - 调研eBPF和NFS相关技术，学习基本用法和案例。

2. **系统设计**：
   - 参与系统架构设计，负责用户态程序部分的设计。
   - 确定用户态程序的技术方案和数据结构。

3. **用户态程序开发**：
   - 编写用户态程序，实现eBPF程序的加载、管理和监控功能。
   - 负责用户态程序的测试和调试，确保其功能正确性和稳定性。
   - 处理内核态传递的数据，实时监控NFS操作的统计数据。

4. **集成测试和文档撰写**：
   - 进行系统的集成测试，验证用户态程序与eBPF程序的协同工作。
   - 编写项目文档，包括技术方案、测试报告、使用说明等。
   - 总结项目经验，准备比赛答辩材料。

**协作方式**：
- 与成员A共同参与系统架构设计和需求分析。
- 定期与成员A交流用户态程序开发中的问题和解决方案，共同优化系统性能。
- 通过代码评审和测试结果共享，确保用户态程序的高质量实现。

### 协作流程

1. **定期会议**：
   - 每周召开一次项目会议，讨论项目进展、遇到的问题和解决方案，确保项目按计划推进。

2. **代码管理**：
   - 使用版本控制工具（Git）进行代码管理，确保代码的版本控制和协同开发。

3. **文档共享**：
   - 使用在线文档工具进行文档共享，确保技术方案、测试报告等文档的实时更新和共同编辑。

4. **测试和调试**：
   - 共同进行系统的集成测试和调试，确保eBPF程序和用户态程序的协同工作和系统的整体稳定性。
</details>
<details><summary>9. 提交仓库目录和文件描述</summary>

### 仓库目录结构

以下是项目仓库的目录结构及各文件的简要描述：

```
/project-root
│
├── LICENSE
│
├── README.md
├── ebpf_nfs.c
│
├── ebpf_nfs.o
│
└── ebpf_nfs.py│


```

### 文件描述

1. **LICENSE**
   - **描述**：该文件包含项目的许可证信息，规定了项目的使用和分发方式。
   - **内容**：使用了MIT的许可条款。

2. **README.md**
   - **描述**：该文件提供项目的比赛文档
   - **内容**：
   ·目标描述
   ·比赛题目分析和相关资料调研
   ·系统框架设计
   ·开发计划
   ·比赛过程中的重要进展
   ·系统测试情况
   ·遇到的主要问题和解决方法
   ·分工和协作
   ·提交仓库目录和文件描述
   ·比赛收获

3. **ebpf_nfs.py**
   - **描述**：本文件是一个利用eBPF技术对NFS操作进行监控与优化的Python脚本。它通过捕获和处理网络数据包，实时监控NFS请求的操作行为，并进行权限控制和频率限制，从而提高系统性能并增强安全性。此脚本在内核态通过eBPF进行数据包解析，并将重要事件通过perf_event传递到用户态进行进一步处理和日志记录。
- **内容**：
 1. **导入模块**：

   - 导入`bcc`, `ctypes`, `socket`, `struct`, `time`, `datetime`, `json`等模块，用于eBPF程序加载、数据结构定义、网络处理和日志记录。

2. **系统启动时间获取**：
   - 读取`/proc/stat`文件中的启动时间，用于计算事件的实际发生时间。

3. **eBPF程序定义**：
   - 使用C语言编写的内核态代码，处理NFS请求的捕获、操作码解析、权限控制、频率监控等。
   - 包含`event_t`事件结构体定义、BPF哈希表定义，以及网络数据包处理逻辑。

4. **用户态事件处理**：
   - 定义Python中的`Event`结构体用于接收内核态传递的事件。
   - 包含事件的解析、日志记录、实时监控输出等逻辑。

5. **日志记录**：
   - 将事件日志记录到`/var/log/ebpf_nfs.log`文件中，以追加模式保存，便于后续分析。

6. **事件处理循环**：
   - 通过`perf_buffer_poll()`方法持续监听并处理从内核态传递的事件，直到手动中断程序。

</details>
<details><summary>10. 比赛收获</summary>

### 技术能力提升

#### 1. **eBPF 与 BPF 编程**

   - **掌握了 eBPF 基础**：学习了如何使用 eBPF（Extended Berkeley Packet Filter）扩展 Linux 内核功能，在内核态实现高效、灵活的网络包处理。
   - **BPF 高级编程**：通过 BPF Compiler Collection (BCC) 与 eBPF 交互，深入理解了如何编写和加载 eBPF 程序，并将其应用于网络包过滤和实时监控。

#### 2. **内核态与用户态交互**

   - **事件传递机制**：掌握了在 eBPF 程序中捕获事件，并通过 `perf_event` 机制将数据从内核态传递到用户态的技术。
   - **性能与安全性监控**：通过事件传递实现了对系统性能和安全性的实时监控，提升了对内核态与用户态之间数据交互的理解。

#### 3. **NFS 协议处理**

   - **NFS 操作解析**：学习了如何在 eBPF 中解析和处理 NFS（Network File System）协议，识别并监控特定的 NFS 操作。
   - **高频操作与权限管理**：通过对 NFS 操作的缓存、频率监控和权限控制，提升了对网络文件系统安全性的理解。

#### 4. **系统性能优化**

   - **缓存与哈希表优化**：通过使用 BPF 哈希表实现操作码缓存和频率监控，掌握了如何优化高频网络请求的处理，提升系统整体性能。
   - **高效事件处理**：通过减少内核态与用户态的交互开销，学会了如何编写高效的事件处理程序。

#### 5. **安全性增强**

   - **权限控制机制**：通过实现对操作码和 IP 地址的权限检查，学习了如何在内核态增强系统的安全性，防止未经授权的操作。
   - **异常行为监控**：通过对访问频率的监控与警报机制，提升了对潜在恶意行为的检测能力，强化了系统的安全性管理。

#### 6. **Python 与 C 语言结合编程**

   - **Python 和 C 语言结合**：通过在 Python 中编写 BPF 程序并调用 C 语言编写的 eBPF 代码，掌握了两种语言之间的高效结合使用。
   - **数据结构与类型转换**：学会了如何在 Python 中定义 C 语言结构体，并进行数据类型转换和处理，这对跨语言编程具有很大帮助。

#### 7. **日志记录与数据分析**

   - **日志管理**：掌握了如何将监控数据记录到日志文件中，并以 JSON 格式存储，方便后续的数据分析和故障排查。
   - **数据格式化与序列化**：通过 `json` 模块学会了如何将事件数据格式化为可读形式，并序列化为 JSON 格式以便记录。

### 团队协作和项目管理

1. **高效的团队协作**
   - **分工明确**：通过明确的任务分工和责任划分，团队成员各自负责不同的模块，确保项目各部分的顺利进行。
   - **定期沟通**：通过定期召开项目会议，讨论项目进展和遇到的问题，及时调整项目计划，保证项目按时完成。

2. **项目管理技能**
   - **计划制定**：在项目初期，我们制定了详细的开发计划，明确了各个阶段的任务和时间安排。
   - **进度跟踪**：通过学习使用版本控制工具（Git）和项目管理工具，实时跟踪项目进度。

### 总结

通过本次比赛，我们不仅初步完成了基于eBPF的增强型网络文件系统的开发任务，还在技术能力、团队协作和项目管理等方面取得了显著的提升。特别是在Linux操作系统的运用技能方面，我们的操作系统相关命令的运用、编程、系统调优和网络管理能力都有了很大的提高。通过该项目代码的开发与实践，提升了对 Linux 内核编程、eBPF 应用、系统性能优化与安全性管理等多个领域的技术能力。同时，也增强了 Python 与 C 语言结合编程、日志管理和实时数据监控的实践经验。这些宝贵的经验和收获，将为我们未来的学习和职业发展打下坚实的基础。
</details>

















