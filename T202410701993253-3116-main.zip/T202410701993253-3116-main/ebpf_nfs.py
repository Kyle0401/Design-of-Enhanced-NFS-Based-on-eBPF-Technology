from bcc import BPF  # 导入BPF模块，用于与eBPF进行交互
import ctypes as ct  # 导入ctypes模块，用于定义C语言结构体
import socket  # 导入socket模块，用于IP地址处理
from struct import pack  # 导入pack函数，用于打包数据
import datetime  # 导入datetime模块，用于时间格式化
import json  # 导入json模块，用于日志输出时序列化数据
import subprocess  # 导入subprocess模块，用于执行系统命令
import os

# 获取系统启动时间，用于计算事件的实际发生时间
# 参考资料来自：https://www.cnblogs.com/liujunjun/p/14764444.html
with open('/proc/stat') as f:
    for line in f:
        if line.startswith('btime'):
            btime = int(line.split()[1])
            break

# 定义eBPF程序，使用C语言编写的内核态代码
# 参考资料来自：https://coolshell.cn/articles/22320.html 和 https://github.com/iovisor/bcc/blob/master/docs/tutorial_bcc_python_developer.md 
# 和 https://wenku.csdn.net/answer/3684e69e7be142929925d0ca29ac3ef4 和 https://www.cnblogs.com/nmgxbc/p/5812377.html
b = BPF(text="""
#include <uapi/linux/bpf.h>  // 包含BPF程序的基本定义
#include <uapi/linux/if_ether.h>  // 包含以太网头文件定义
#include <uapi/linux/ip.h>  // 包含IP头文件定义
#include <uapi/linux/tcp.h>  // 包含TCP头文件定义
#include <linux/in.h>  // 包含网络协议相关的定义
#include <linux/pkt_cls.h>  // 包含用于TC的包分类定义

// 定义一个事件结构体，用于存储捕获到的数据
struct event_t {
    u64 ts;  // 时间戳，表示事件发生的时间
    u16 sport;  // 源端口
    u16 dport;  // 目的端口
    u32 saddr;  // 源IP地址
    u32 daddr;  // 目的IP地址
    u8 nfs_op;  // NFS操作码
    u8 user_space_flag;  // 标志是否需要用户态处理
    u8 alert_IP;  // IP安全警报标志
    u8 alert_OP;  // 操作安全警报标志
    u8 perm_flag; // 权限警报标志
};

// 定义BPF哈希表和输出通道
BPF_PERF_OUTPUT(events);  // 用于向用户态传递事件
BPF_HASH(nfs_cache, u64, u8);  // 用于缓存NFS操作码
BPF_HASH(ip_access_count, u32, u64);  // 用于记录每个IP的访问次数
BPF_HASH(nfs_op_count, u32, u64);  // 用于记录每个NFS操作码的频率
BPF_HASH(user_space_ops_map, u32, u8);  // 用于配置哪些操作码需要用户态处理
BPF_HASH(permission_map, u32, u8);  // 用于配置NFS操作的权限控制
BPF_HASH(nfs_cache_map, u64, struct event_t);  // 用于缓存完整的事件结构

// 一些常量定义
#define SETATTR_OP_CODE 34  // SETATTR操作的操作码
#define NFS_OP_OFFSET 0x00f9  // NFS操作码在数据包中一般情况下的偏移量
#define OTHER_OP_OFFSET 0x0101 // 一些别的操作码在数据包中的偏移量
#define MAX_ACCESS_THRESHOLD 1000  // IP访问频率阈值
#define HIGH_FREQ_THRESHOLD 50  // 操作码高频率阈值
#define WRITE_OP_CODE 38 // WRITE操作的操作码
#define CLOSE_OP_OFFSET 0x0111 // CLOSE操作的偏移量
#define OPEN_OP_CODE 18  // OPEN操作的操作码
#define REPLY_OP_OFFSET 0x00a1 // 回复操作的偏移量
#define RETURN_STATUS_OFFSET 0x0061 // 返回状态的偏移量
#define NFS4ERR_ROFS 30 // 只读文件系统错误码

// 处理网络数据包的XDP程序
// 参考资料：https://ebpf-docs.dylanreimerink.nl/linux/helper-function/bpf_skb_load_bytes/ 和 https://www.cnblogs.com/ink-white/p/16816464.html
int handle_xdp(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;  // 获取数据包结束的指针
    void *data = (void *)(long)ctx->data;  // 获取数据包开始的指针

    struct ethhdr *eth = data;  // 定义以太网头结构体
    // 检查以太网头是否完整
    if (data + sizeof(*eth) > data_end) {
        return XDP_PASS;  // 数据包不完整，直接放行
    }

    // 只处理IP协议的数据包
    if (eth->h_proto != htons(ETH_P_IP)) {
        return XDP_PASS;  // 非IP数据包，放行
    }

    struct iphdr *ip = data + sizeof(*eth);  // 定义IP头结构体
    // 检查IP头是否完整
    if (data + sizeof(*eth) + sizeof(*ip) > data_end) {
        return XDP_PASS;  // 数据包不完整，直接放行
    }

    // 只处理TCP协议的数据包
    if (ip->protocol != IPPROTO_TCP) {
        return XDP_PASS;  // 非TCP数据包，放行
    }

    struct tcphdr *tcp = (void *)ip + sizeof(*ip);  // 定义TCP头结构体
    // 检查TCP头是否完整
    if (data + sizeof(*eth) + sizeof(*ip) + sizeof(*tcp) > data_end) {
        return XDP_PASS;  // 数据包不完整，直接放行
    }

    // 只处理目标端口为2049的数据包，即NFS服务端口
    if (tcp->dest != htons(2049)) {
        return XDP_PASS;  // 非NFS数据包，放行
    }

    int nfs_op_offset = NFS_OP_OFFSET;  // 定义操作码偏移量
    u8 nfs_op;  // 定义NFS操作码变量
    // 检查操作码是否在数据包范围内
    if (data + nfs_op_offset + sizeof(nfs_op) > data_end) {
        return XDP_PASS;  // 操作码不在范围内，直接放行
    }

    // 从数据包中加载NFS操作码
    nfs_op = *(u8 *)(data + nfs_op_offset);

    if (nfs_op == 0) {
        // 检查CLOSE操作码是否在数据包范围内
        if (data + CLOSE_OP_OFFSET + sizeof(nfs_op) > data_end) {
            return XDP_PASS;  // 操作码不在范围内，直接放行
        }
        // 检查是否为CLOSE操作
        if (*(u8 *)(data + CLOSE_OP_OFFSET) == 4) {
            nfs_op = *(u8 *)(data + CLOSE_OP_OFFSET);  // 设置操作码为CLOSE
        } else {
            nfs_op = 0;  // 否则设置为0
        }
    }

    if (nfs_op == 0) {
        // 检查其他操作码是否在数据包范围内
        if (data + OTHER_OP_OFFSET + sizeof(nfs_op) > data_end) {
            return XDP_PASS;  // 操作码不在范围内，直接放行
        }
        // 从数据包中加载可能的其他操作码
        u8 possible_other_op = *(u8 *)(data + OTHER_OP_OFFSET);
        nfs_op = possible_other_op;
    }

    // 生成用于缓存的键值，基于源IP和TCP序列号
    u64 key = ((u64)ip->saddr << 32) | tcp->seq;
    u8 *cached_op = nfs_cache.lookup(&key);  // 查询缓存是否存在该操作码
    if (cached_op) {
        nfs_op = *cached_op;  // 如果缓存命中，使用缓存中的操作码
    } else {
        nfs_cache.update(&key, &nfs_op);  // 否则，更新缓存
    }

    // 查询user_space_ops_map，确定该操作是否需要用户态处理
    u32 op_key = (u32)nfs_op;
    u8 *user_space_flag_ptr = user_space_ops_map.lookup(&op_key);
    u8 user_space_flag = 0;  // 默认初始化为0，表示不需要用户态处理

    if (user_space_flag_ptr) {
        user_space_flag = *user_space_flag_ptr;  // 如果找到对应的操作码，则设置为需要用户态处理
    }

    // 更新IP访问次数计数
    u64 *count = ip_access_count.lookup(&ip->saddr);
    if (count) {
        *count += 1;  // 如果存在计数，增加访问次数
    } else {
        u64 initial_count = 1;
        ip_access_count.update(&ip->saddr, &initial_count);  // 否则，初始化计数
    }

    u8 alert_IP = 0;  // 初始化警报标志
    // 如果访问次数超过阈值，触发警报
    if (count && *count > MAX_ACCESS_THRESHOLD) {
        alert_IP = 1;
    }

    // 更新操作码频率计数
    u64 *op_count = nfs_op_count.lookup(&op_key);
    if (op_count) {
        *op_count += 1;  // 如果存在计数，增加操作码频率
    } else {
        u64 initial_count = 1;
        nfs_op_count.update(&op_key, &initial_count);  // 否则，初始化计数
    }

    u8 alert_OP = 0;
    // 如果操作码频率超过阈值，触发警报
    if (op_count && *op_count > HIGH_FREQ_THRESHOLD) {
        alert_OP = 1;
    }

    u8 permission_flag = 1;
    // 检查权限控制，如果该操作或IP被禁止，返回错误
    u8 *perm_flag = permission_map.lookup(&op_key);
    if (perm_flag && *perm_flag == 0) {
        permission_flag = *perm_flag;
        struct event_t event = {};
        event.ts = bpf_ktime_get_ns();  // 获取事件发生的时间戳
        event.sport = tcp->source;  // 源端口
        event.dport = tcp->dest;  // 目的端口
        event.saddr = ip->saddr;  // 源IP地址
        event.daddr = ip->daddr;  // 目的IP地址
        event.nfs_op = nfs_op;  // NFS操作码
        event.user_space_flag = user_space_flag;  // 用户态处理标志
        event.alert_IP = alert_IP;  // IP安全警报标志
        event.alert_OP = alert_OP;  // OP安全警报标志
        event.perm_flag = permission_flag; // 权限警报标志

        events.perf_submit(ctx, &event, sizeof(event));  // 向用户态传递事件

        // 无权限，直接阻止操作并记录日志
        return XDP_PASS;
    }

    // 创建事件结构体并填充数据
    struct event_t event = {};
    event.ts = bpf_ktime_get_ns();  // 获取事件发生的时间戳
    event.sport = tcp->source;  // 源端口
    event.dport = tcp->dest;  // 目的端口
    event.saddr = ip->saddr;  // 源IP地址
    event.daddr = ip->daddr;  // 目的IP地址
    event.nfs_op = nfs_op;  // NFS操作码
    event.user_space_flag = user_space_flag;  // 用户态处理标志
    event.alert_IP = alert_IP;  // IP安全警报标志
    event.alert_OP = alert_OP;  // OP安全警报标志
    event.perm_flag = permission_flag; // 权限警报标志

    events.perf_submit(ctx, &event, sizeof(event));  // 向用户态传递事件
    nfs_cache_map.update(&key, &event);  // 更新缓存

    return XDP_PASS;
}

""")

# 加载和附加XDP程序
fn_xdp = b.load_func("handle_xdp", BPF.XDP)  # 将eBPF函数附加到XDP（eXpress Data Path）上，用于高效处理数据包
b.attach_xdp("enp0s3", fn_xdp, 0)  # 将该eBPF程序附加到网络接口enp0s3

# 初始化 user_space_ops_map 和 permission_map
def init_user_space_ops_map():
    ops = [25]  # 需要用户态处理的操作码列表
    for op in ops:
        flag = ct.c_uint8(1)
        b["user_space_ops_map"].__setitem__(ct.c_uint32(op), flag)

def init_permission_map():
    write_op_code = 38  # WRITE操作的操作码
    perm_key = ct.c_uint32(write_op_code)
    zero = ct.c_uint8(0)
    b["permission_map"].__setitem__(perm_key, zero)  # 设置WRITE操作为无权限

init_user_space_ops_map()  # 初始化user_space_ops_map
init_permission_map()  # 初始化permission_map


# 定义用于处理事件的结构体
# 参考教程和资料：https://docs.python.org/3/library/ctypes.html
class Event(ct.Structure):
    _fields_ = [
        ("ts", ct.c_uint64),  # 时间戳
        ("sport", ct.c_uint16),  # 源端口
        ("dport", ct.c_uint16),  # 目的端口
        ("saddr", ct.c_uint32),  # 源IP地址
        ("daddr", ct.c_uint32),  # 目的IP地址
        ("nfs_op", ct.c_uint8),  # NFS操作码，通过抓包分析结构得到
        ("user_space_flag", ct.c_uint8),  # 用户态处理标志
        ("alert_IP", ct.c_uint8),  # IP安全警报标志
        ("alert_OP", ct.c_uint8),  # OP安全警报标志
        ("perm_flag", ct.c_uint8)  # 权限警报标志
    ]

# 将IP地址转换为字符串形式
# 参考资料：https://bitmingw.com/2018/05/06/get-ip-address-of-network-interface-in-python/ 和 https://blog.csdn.net/jackyzhousales/article/details/78036097
def ip_to_str(ip):
    return socket.inet_ntoa(pack("!I", ip))

# 将NFS操作码转换为可读的字符串形式
# 参考资料：https://www.rfc-editor.org/rfc/rfc7530#page-12
def nfs_op_to_str(nfs_op):
    nfs_ops = {
        0: "NULL",
        1: "COMPOUND",
        3: "ACCESS",
        4: "CLOSE",
        5: "COMMIT",
        6: "CREATE",
        7: "DELEGPURGE",
        8: "DELEGRETURN",
        9: "GETATTR",
        10: "GETFH",
        11: "LINK",
        12: "LOCK",
        13: "LOCKT",
        14: "LOCKU",
        15: "LOOKUP",
        16: "LOOKUPP",
        17: "NVERIFY",
        18: "OPEN",
        19: "OPENATTR",
        20: "OPEN_CONFIRM",
        21: "OPEN_DOWNGRADE",
        22: "PUTFH",
        23: "PUTPUBFH",
        24: "PUTROOTFH",
        25: "READ",
        26: "READDIR",
        27: "READLINK",
        28: "REMOVE",
        29: "RENAME",
        30: "RENEW",
        31: "RESTOREFH",
        32: "SAVEFH",
        33: "SECINFO",
        34: "SETATTR",
        35: "SETCLIENTID",
        36: "SETCLIENTID_CONFIRM",
        37: "VERIFY",
        38: "WRITE",
        39: "RELEASE_LOCKOWNER",
        40: "BACKCHANNEL_CTL",
        41: "BIND_CONN_TO_SESSION",
        42: "EXCHANGE_ID",
        43: "CREATE_SESSION",
        44: "DESTROY_SESSION",
        45: "FREE_STATEID",
        46: "GET_DIR_DELEGATION",
        47: "GETDEVICEINFO",
        48: "GETDEVICELIST",
        49: "LAYOUTCOMMIT",
        50: "LAYOUTGET",
        51: "LAYOUTRETURN",
        52: "SECINFO_NO_NAME",
        53: "SEQUENCE",
        54: "SET_SSV",
        55: "TEST_STATEID",
        56: "WANT_DELEGATION",
        57: "DESTROY_CLIENTID",
        58: "RECLAIM_COMPLETE",
    }
    return nfs_ops.get(nfs_op, "Unknown")  # 返回操作码对应的字符串，如果找不到则返回"Unknown"

# 将时间戳转换为可读的日期时间格式
# 参考资料：https://www.runoob.com/python3/python-timstamp-str.html
def timestamp_to_datetime(ts):
    event_time = btime + ts / 1e9  # 将时间戳转换为秒级时间
    dt = datetime.datetime.fromtimestamp(event_time)  # 创建datetime对象
    return dt.strftime("%Y-%m-%d %H:%M:%S")  # 返回格式化的时间字符串

# 将事件记录到日志文件中
# 参考资料：https://blog.csdn.net/qq_46293423/article/details/105785007
def log_event_to_file(event):
    log_entry = {
        "timestamp": timestamp_to_datetime(event.ts),  # 时间戳
        "saddr": ip_to_str(socket.ntohl(event.saddr)),  # 源IP地址
        "daddr": ip_to_str(socket.ntohl(event.daddr)),  # 目的IP地址
        "sport": socket.ntohs(event.sport),  # 源端口
        "dport": socket.ntohs(event.dport),  # 目的端口
        "nfs_op": nfs_op_to_str(event.nfs_op),  # NFS操作码
        "user_space_flag": event.user_space_flag,  # 用户态处理标志
        "alert_IP": event.alert_IP,  # IP安全警报标志
        "alert_OP": event.alert_OP,  # OP安全警报标志
        "perm_flag": event.perm_flag  # 权限警报标志
    }
    # 以追加模式打开日志文件，并写入事件日志
    with open("/var/log/ebpf_nfs.log", "a") as log_file:
        log_file.write(json.dumps(log_entry) + "\n")

# 处理捕获到的事件
# 参考资料：https://www.cnblogs.com/imteck4713/p/18258400 
def print_event(cpu, data, size):
    event = ct.cast(data, ct.POINTER(Event)).contents  # 将数据转换为Event结构体，得到一个包含事件信息的 event 对象
    log_event_to_file(event)  # 记录事件到日志文件
    saddr = ip_to_str(socket.ntohl(event.saddr))  # 转换源IP地址
    daddr = ip_to_str(socket.ntohl(event.daddr))  # 转换目的IP地址
    sport = socket.ntohs(event.sport)  # 转换源端口
    dport = socket.ntohs(event.dport)  # 转换目的端口
    nfs_op = nfs_op_to_str(event.nfs_op)  # 转换NFS操作码
    timestamp = timestamp_to_datetime(event.ts)  # 转换时间戳
    # 根据事件标志打印不同的日志信息
    if event.perm_flag == 0:
        print(f"时间: {timestamp}, 源IP为: {saddr}的NFS操作: {nfs_op} 没有访问权限")
    else:
        if event.alert_IP:
            print(f"时间: {timestamp}, 源IP: {saddr}, 目的IP: {daddr}, NFS操作: {nfs_op} - 警报: IP访问频率异常!")
        if event.alert_OP:
            print(f"时间: {timestamp}, 源IP: {saddr}, 目的IP: {daddr}, NFS操作: {nfs_op} - 警报: 操作频率异常!")
        elif event.user_space_flag:
            print(f"时间: {timestamp}, 源IP: {saddr}, 目的IP: {daddr}, 源端口: {sport}, 目的端口: {dport}, NFS操作: {nfs_op} (需要用户态处理)")
        else:
            print(f"时间: {timestamp}, 源IP: {saddr}, 目的IP: {daddr}, 源端口: {sport}, 目的端口: {dport}, NFS操作: {nfs_op} (内核态处理)")

# 打开perf缓冲区，用于捕获事件
# 参考资料：https://www.cnblogs.com/lianyihong/p/17922818.html
b["events"].open_perf_buffer(print_event)

print("eBPF程序已加载并附加。正在监控NFS请求...")

# 加载和附加TC程序
tc_prog = "/root/桌面/ebpf_nfs.o"
dev = "enp0s3"

#参考资料：https://www.cnblogs.com/dream397/p/14435876.html
# 添加TC qdisc
subprocess.call(f"tc qdisc add dev {dev} clsact", shell=True)
# 添加TC过滤器并附加BPF程序
subprocess.call(f"tc filter add dev {dev} egress bpf direct-action obj {tc_prog} sec classifier", shell=True)


# 持续轮询缓冲区以处理事件
# 参考资料：https://eunomia.dev/zh/tutorials/bcc-documents/reference_guide/#_1
while True:
    try:
        b.perf_buffer_poll()  # 轮询缓冲区
    except KeyboardInterrupt:
        subprocess.call(f"tc qdisc del dev {dev} clsact", shell=True)
        exit()  # 捕获键盘中断信号后退出程序
