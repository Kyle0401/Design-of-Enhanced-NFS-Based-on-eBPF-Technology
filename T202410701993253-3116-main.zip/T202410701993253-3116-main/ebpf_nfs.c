#include <linux/bpf.h>
#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/in.h>
#include <linux/pkt_cls.h>
#include <bpf/bpf_helpers.h>

#define REPLY_OP_OFFSET 0x00a1
#define RETURN_STATUS_OFFSET 0x0061
#define WRITE_OP_CODE 38
#define NFS4ERR_ROFS 30

// 定义一个BPF哈希表，用于存储权限控制信息
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 50);
    __type(key, __u32);
    __type(value, __u8);
} permission_map SEC(".maps");

// 定义一个eBPF程序，用于处理TC（Traffic Control）数据包
SEC("classifier")
int handle_tc(struct __sk_buff *skb) {
    void *data_end = (void *)(long)skb->data_end;
    void *data = (void *)(long)skb->data;

    struct ethhdr *eth = data;
    if (data + sizeof(*eth) > data_end) {
        return TC_ACT_OK;
    }

    if (eth->h_proto != __constant_htons(ETH_P_IP)) {
        return TC_ACT_OK;
    }

    struct iphdr *ip = data + sizeof(*eth);
    if (data + sizeof(*eth) + sizeof(*ip) > data_end) {
        return TC_ACT_OK;
    }

    if (ip->protocol != IPPROTO_TCP) {
        return TC_ACT_OK;
    }

    struct tcphdr *tcp = (void *)ip + sizeof(*ip);
    if (data + sizeof(*eth) + sizeof(*ip) + sizeof(*tcp) > data_end) {
        return TC_ACT_OK;
    }

    if (tcp->source != __constant_htons(2049)) {
        return TC_ACT_OK;
    }

    __u8 nfs_op;
    int reply_op_offset = REPLY_OP_OFFSET;
    if (data + reply_op_offset + sizeof(nfs_op) > data_end) {
        return TC_ACT_OK;
    }

    nfs_op = *(__u8 *)(data + reply_op_offset);

    // 检查并初始化权限控制
    __u32 write_op_code = WRITE_OP_CODE;
    __u8 zero = 0;
    __u8 *perm_flag = bpf_map_lookup_elem(&permission_map, &write_op_code);
    if (!perm_flag) {
        bpf_map_update_elem(&permission_map, &write_op_code, &zero, BPF_ANY);
    }

    // 检查是否为WRITE操作码
    if (nfs_op == WRITE_OP_CODE) {
        perm_flag = bpf_map_lookup_elem(&permission_map, &write_op_code);
        if (perm_flag && *perm_flag == 0) {
            __u32 *status_code = (__u32 *)(data + RETURN_STATUS_OFFSET);
            *status_code = __constant_htonl(NFS4ERR_ROFS);
        }
    }

    return TC_ACT_OK;
}

char __license[] SEC("license") = "GPL";
